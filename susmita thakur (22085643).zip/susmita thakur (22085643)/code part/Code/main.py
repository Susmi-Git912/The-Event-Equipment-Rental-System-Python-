from datetime import datetime
from read import load_land_data, displayData  # Import necessary modules and functions
from operations import rent_land, return_land

# Print welcome message and system banner
print("************************************************************************************************************************************************")
print(" \t \t \t \t \t \t \t Welcome to Land Rental Management System")
print("************************************************************************************************************************************************")
print("\n")

lands = load_land_data()  # Load initial land data from file
loop = True  # Initialize loop control variable
while loop:  # Start main loop
    # Display options for user
    print("1. Rent a Land")
    print("2. Return a Land")
    print("3. Exit")
    print("\n")
    displayData()  # Display current land data
    
    valid_input = False  # Flag to check valid input
    while not valid_input:  # Loop until valid input is received
        try:
            user_choice = int(input("Enter your choice: "))  # Prompt user for choice
            valid_input = True  # Set flag to True if input is valid
        except:  # Catch any exception
            print("Invalid input. Please enter a valid option (1, 2, or 3).")  # Error message

    print("\n")

    if user_choice == 1:  # Option 1: Rent a land
        valid_land_id = False  # Flag to check valid land ID
        while not valid_land_id:  # Loop until valid land ID is received
            try:
                land_id = int(input("Enter the ID of the land you want to rent: "))  # Prompt for land ID
                valid_land_id = True  # Set flag to True if input is valid
            except:  # Catch any exception
                print("Invalid input for land ID. Please enter a valid integer ID.")  # Error message

        try:
            months = int(input("Enter the number of months you want to rent the land for: "))  # Get rental duration
            customer_name = input("Enter your name: ")  # Get customer name
            rent_land(lands, land_id, months, customer_name)  # Call function to rent the land
        except:
            print("An error occurred while trying to process your request.")  # General error message

    elif user_choice == 2:  # Option 2: Return a land
        valid_land_id = False  # Flag to check valid land ID
        while not valid_land_id:  # Loop until valid land ID is received
            try:
                land_id = int(input("Enter the ID of the land you want to return: "))  # Prompt for land ID
                valid_land_id = True  # Set flag to True if input is valid
            except:  # Catch any exception
                print("Invalid input for land ID. Please enter a valid integer ID.")  # Error message

        try:
            customer_name = input("Enter your name: ")  # Get customer name
            return_land(lands, land_id, customer_name)  # Call function to return the land
        except:
            print("An error occurred while trying to process your request.")  # General error message

    elif user_choice == 3:  # Option 3: Exit the system
        loop = False  # Break the loop to exit
        # Print exit message and banner
        print("************************************************************************************************************************************************")
        print("Thank you for using our Land Rental Management System!")
        print("************************************************************************************************************************************************")
        print("\n")

    else:  # Handle invalid option
        print("Invalid option. Please enter a valid option (1, 2, or 3).")  # Error message
        print("\n")
