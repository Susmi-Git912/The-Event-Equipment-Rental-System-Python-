from datetime import datetime  # Import datetime for handling timestamps
from update import update_status_in_file  # Import function to update land status in a file

def rent_land(lands, land_id, months, customer_name):
    """
    Rent a land by updating its status, editing source, and generating a rental invoice.
    """
    try:
        for land in lands:  # Iterate through the list of lands
            if land["id"] == land_id:  # Check if current land ID matches the requested land ID
                if land["status"] == "Available":  # Check if the land is available for renting
                    land["status"] = "Not Available"  # Update land status to 'Not Available'
                    update_status_in_file(land_id, "Not Available")  # Update the status in the source file
                    rent_amount = land["rent"] * months  # Calculate the total rent amount
                    print(f"Land ID {land_id} rented for {months} months by {customer_name}. Invoice Amount: NPR {rent_amount}")  # Print rental details
                    generate_rental_invoice(land_id, customer_name, months, rent_amount, lands)  # Generate a rental invoice
                else:
                    print(f"Land ID {land_id} is already rented.")  # Notify that the land is already rented
                break
        else:
            print(f"Land ID {land_id} not found.")  # Notify if the land ID was not found in the list
    except:
        print("An error occurred while processing the rent operation.")  # General error handling

def return_land(lands, land_id, customer_name):
    """
    Return a rented land by updating its status, editing source, and generating a return invoice.
    """
    try:
        for land in lands:  # Iterate through the list of lands
            if land["id"] == land_id:  # Check if current land ID matches the requested land ID
                if land["status"].strip() == "Not Available":  # Check if the land is currently rented
                    land["status"] = "Available"  # Update land status to 'Available'
                    update_status_in_file(land_id, "Available")  # Update the status in the source file
                    print(f"Land ID {land_id} returned by {customer_name}. Status updated to 'Available'.")  # Print return details
                    generate_return_invoice(land_id, customer_name, lands)  # Generate a return invoice
                    break
                else:
                    print(f"Land ID {land_id} is currently not rented.")  # Notify if the land is not rented
        else:
            print(f"Land ID {land_id} not found.")  # Notify if the land ID was not found in the list
    except:
        print("An error occurred while processing the return operation.")  # General error handling

def generate_rental_invoice(land_id, customer_name, months, rent_amount, lands):
    """
    Generate a rental invoice for a rented land.
    """
    try:
        timestamp = datetime.now().strftime("%Y-%m-%d %H-%M-%S")  # Get current timestamp for the invoice
        invoice_text = "--- Land Rental Invoice ---\n"  # Start invoice text
        invoice_text += f"Customer Name: {customer_name}\n"  # Add customer name to invoice
        invoice_text += f"Timestamp: {timestamp}\n\n"  # Add timestamp to invoice

        for land in lands:  # Iterate through the list of lands to find the rented land
            if land["id"] == land_id:
                invoice_text += f"Land ID: {land_id}\n"  # Add land ID to invoice
                invoice_text += f"City/District: {land['location']}\n"  # Add location to invoice
                invoice_text += f"Land Faced: {land['direction']}\n"  # Add direction to invoice
                invoice_text += f"Area: {land['area']} sq. meters\n"  # Add area to invoice
                invoice_text += f"Rent Duration: {months} months\n"  # Add duration to invoice
                invoice_text += f"Rent Amount: NPR {rent_amount}\n\n"  # Add rent amount to invoice

        filename = f"rental_invoice_{customer_name}_{timestamp}.txt"  # Create a filename for the invoice
        with open(filename, "w") as file:  # Open file in write mode
            file.write(invoice_text)  # Write the invoice text to the file
        print(f"Invoice saved as {filename}")  # Notify that the invoice was saved
    except:
        print("An error occurred while generating rental invoice.")  # General error handling for invoice generation

def generate_return_invoice(land_id, customer_name, lands):
    """
    Generate a return invoice for a returned land.
    """
    try:
        timestamp = datetime.now().strftime("%Y-%m-%d %H-%M-%S")  # Get current timestamp for the invoice
        invoice_text = "--- Land Return Invoice ---\n"  # Start return invoice text
        invoice_text += f"Customer Name: {customer_name}\n"  # Add customer name to invoice
        invoice_text += f"Timestamp: {timestamp}\n\n"  # Add timestamp to invoice

        for land in lands:  # Iterate through the list of lands to find the returned land
            if land["id"] == land_id:
                invoice_text += "Land ID: {}\n".format(land_id)  # Add land ID to invoice
                invoice_text += "City/District: {}\n".format(land['location'])  # Add location to invoice
                invoice_text += "Land Faced: {}\n".format(land['direction'])  # Add direction to invoice
                invoice_text += "Area: {} anna\n".format(land['area'])  # Add area to invoice
                invoice_text += "Status: {}\n\n".format(land['status'])  # Add status to invoice

        filename = f"return_invoice_{customer_name}_{timestamp}.txt"  # Create a filename for the return invoice
        with open(filename, "w") as file:  # Open file in write mode
            file.write(invoice_text)  # Write the return invoice text to the file
        print(f"Invoice saved as {filename}")  # Notify that the return invoice was saved
    except:
        print("An error occurred while generating return invoice.")  # General error handling for return invoice generation
