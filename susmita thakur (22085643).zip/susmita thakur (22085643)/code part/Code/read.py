def displayData():
    # Try to display data from the file
    try:
        print("\n-------------------------------------------------------------------------------------------------------------------")
        print("{:<10}{:<30}{:<10}{:<10}{:<10}{:<10}".format("Kitta", "City", "Direction", "Anna", "Price", "Status"))  # Print table headers
        print("-------------------------------------------------------------------------------------------------------------------")
        with open("land_data.txt", "r") as file:  # Open the land data file for reading
            for line in file:  # Iterate over each line in the file
                Kitta, City, Direction, Anna, Price, Status = line.strip().split(",")  # Parse line into components
                print("{:<10}{:<30}{:<10}{:<10}{:<10}{:<10}".format(Kitta, City, Direction, Anna, Price, Status))  # Print each land's details formatted
        print("-------------------------------------------------------------------------------------------------------------------\n")
    except FileNotFoundError:  # Handle the case where the file is not found
        print("Error: File 'land_data.txt' not found.")
    except:  # Catch any other exceptions that may occur
        print("An error occurred while displaying land data.")

def load_land_data():
    lands = []  # Initialize an empty list to store land data
    # Try to load land data from the file
    try:
        with open('land_data.txt', 'r') as file:  # Open the land data file for reading
            for line in file:  # Iterate over each line in the file
                line = line.replace('\n', '')  # Remove newline characters from the line
                fields = line.split(',')  # Split the line into fields
                land = {  # Create a dictionary for the land
                    "id": int(fields[0]),  # Convert id to integer
                    "location": fields[1].strip(),  # Strip spaces from location
                    "direction": fields[2].strip(),  # Strip spaces from direction
                    "area": int(fields[3]),  # Convert area to integer
                    "rent": float(fields[4]),  # Convert rent to float
                    "status": fields[5].strip()  # Strip spaces from status
                }
                lands.append(land)  # Append the land dictionary to the list
    except FileNotFoundError:  # Handle the case where the file is not found
        print("Error: File 'land_data.txt' not found. Please check the source file name.")
        exit()
    except:  # Catch any other exceptions that may occur
        print("An error occurred while loading land data:")
        exit()
    return lands  # Return the list of loaded lands
