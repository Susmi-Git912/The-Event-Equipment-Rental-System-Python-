def update_status_in_file(land_id, new_status):
    """
    Update the status of a land in the source file.
    
    Parameters:
    - land_id (int): ID of the land to update.
    - new_status (str): New status of the land.
    """
    try:
        with open('land_data.txt', 'r') as file:  # Open the land data file in read mode
            lines = file.readlines()  # Read all lines from the file

        for i, line in enumerate(lines):  # Iterate over each line with index
            fields = line.strip().split(',')  # Split the line into fields and strip whitespace
            if int(fields[0]) == land_id:  # Check if the current land's ID matches the specified ID
                fields[5] = new_status  # Update the status in the fields list
                lines[i] = ','.join(map(str, fields)) + '\n'  # Reconstruct the line and add a newline character
                break  # Break the loop once the matching land is updated

        with open('land_data.txt', 'w') as file:  # Open the land data file in write mode
            file.writelines(lines)  # Write the modified lines back to the file
    except:  # Catch any exception that may occur
        print("An error occurred while updating status in file.")  # Print a generic error message
